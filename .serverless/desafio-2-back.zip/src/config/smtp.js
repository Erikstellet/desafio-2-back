// Coloque suas informações do Outlook 

module.exports =
{
  host: "smtp.outlook.com",
  port: 587,
  user: "estudoti072021@outlook.com",
  pass: "estudandoaws.19",
}